/********************************************************************************
* main.cpp: Demonstration av klass i C++ f�r lagring samt utskrift av persondata.
********************************************************************************/
#include "person.hpp"
#include <clocale>
#include <fstream>

/********************************************************************************
* main: Lagrar personuppgifter f�r tre personer och skriver ut i terminalen.
*       Undantag sker om dynamiskt minne inte kunde allokeras, d� avslutas
*       programmet med felkod 1.
********************************************************************************/
int main(void)
{
   setlocale(LC_ALL, "Swedish");

   person p1("Erik Pihl", 31, "L�rdomsgatan 3", "Teacher", gender::male);
   person p2("Donald Duck", 88, "1313 Webfoot Street", "Comical character", gender::male);

   person* p3 = new person("Bruce Wayne", 40, "Wayne Manor", "Batman", gender::male);
   std::ofstream ostream("persons.txt", std::ios::out);

   if (!p3) return 1;

   p1.print();
   p2.print();
   p3->print();

   p1.print(ostream);
   p2.print(ostream);
   p3->print(ostream);

   delete p3;
   return 0;
}